package com.example.pokemon;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class pokemon {
     String name;
    private int image;
    private int Attack;
    private int Defence;
    private int Total;

    public pokemon(String name, int image, int attack, int defence, int total) {
        this.name = name;
        this.image = image;
        Attack = attack;
        Defence = defence;
        Total = total;
    }

    public pokemon(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getAttack() {
        return Attack;
    }

    public void setAttack(int attack) {
        Attack = attack;
    }

    public int getDefence() {
        return Defence;
    }

    public void setDefence(int defence) {
        Defence = defence;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int total) {
        Total = total;
    }

    public static class pokemonAdapter extends RecyclerView.Adapter {

        ArrayList<pokemon> pArray;
        Context context;

        public pokemonAdapter(ArrayList<pokemon> pArray, Context context) {
            this.pArray = pArray;
            this.context = context;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()) .inflate(R.layout.pokemon,parent,false);
           ViewHolder vh = new ViewHolder(v);

            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            ((ViewHolder)holder).img.setImageResource(pArray.get(position).getImage());
            ((ViewHolder)holder).total.setText(pArray.get(position).getTotal());
            ((ViewHolder)holder).name.setText(pArray.get(position).getName());




        }

        @Override
        public int getItemCount() {
            return pArray.size();
        }

        public static class ViewHolder extends RecyclerView.ViewHolder{
            public ImageView img ;
            public TextView name ;
            public TextView total ;
            public View view ;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                view = itemView ;
                img = itemView.findViewById(R.id.imageView);
                name = itemView.findViewById(R.id.textView);
                total = itemView.findViewById(R.id.textView3);
            }
        }



    }
}
